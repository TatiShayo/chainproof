import { createClient } from "@supabase/supabase-js";
import { NextResponse } from "next/server";

export async function GET(
  request: Request,
  { params }: { params: Promise<{ token: string }> }
) {
  try {
    const { token } = await params;

    const supabaseAdmin = createClient(
      process.env.NEXT_PUBLIC_SUPABASE_URL!,
      process.env.SUPABASE_SERVICE_ROLE_KEY!
    );

    // First, check by payment_token
    let { data: invoice } = await supabaseAdmin
      .from("invoices")
      .select("*, client:clients(*), items:invoice_items(*)")
      .eq("payment_token", token)
      .single();

    if (!invoice) {
      // Check by share_token
      const { data: shareToken } = await supabaseAdmin
        .from("share_tokens")
        .select("invoice_id")
        .eq("token", token)
        .single();

      if (shareToken) {
        const { data: sharedInvoice } = await supabaseAdmin
          .from("invoices")
          .select("*, client:clients(*), items:invoice_items(*)")
          .eq("id", shareToken.invoice_id)
          .single();
        invoice = sharedInvoice;
      }
    }

    if (!invoice) {
      return NextResponse.json({ error: "Invoice not found" }, { status: 404 });
    }

    return NextResponse.json(invoice);
  } catch (error) {
    console.error("Fetch pay invoice error:", error);
    return NextResponse.json(
      { error: "Failed to fetch invoice" },
      { status: 500 }
    );
  }
}
